package com.nehaar.imadpart1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.nehaar.imadpart1.R.id.buttonMulti


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var buttonAdd = findViewById<Button>(R.id.buttonAdd)

        var textResult = findViewById<TextView>(R.id.textResult)

        var editTextNumber1 = findViewById<EditText>(R.id.editTextNumber1)

        var editTextNumber2 = findViewById<EditText>(R.id.editTextNumber2)

        var buttonSub = findViewById<Button>(R.id.buttonSub)

        var buttonMulti = findViewById<Button>(R.id.buttonMulti)

        var buttonDiv = findViewById<Button>(R.id.buttonDiv)

        buttonAdd.setOnClickListener {
           val number1 = editTextNumber1.text.toString().toInt()
            val number2 = editTextNumber2.text.toString().toInt()
            val result = number1 + number2

            val output = "$number1 + $number2 = $result"
            textResult.text = output
        }

        buttonSub.setOnClickListener {
            val number1 = editTextNumber1.text.toString().toInt()
            val number2 = editTextNumber2.text.toString().toInt()
            val result = number1 - number2

            val output = "$number1 - $number2 = $result"
            textResult.text = output
        }

        buttonMulti.setOnClickListener {
            val number1 = editTextNumber1.text.toString().toInt()
            val number2 = editTextNumber2.text.toString().toInt()
            val result = number1 * number2

            val output = "$number1 * $number2 = $result"
            textResult.text = output
        }

        buttonDiv.setOnClickListener {
            val number1 = editTextNumber1.text.toString().toInt()
            val number2 = editTextNumber2.text.toString().toInt()
            val result = number1 / number2

            val output = "$number1 / $number2 = $result"
            textResult.text = output
        }

    }
}